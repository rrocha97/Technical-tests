(req: any, res: any) => {
    res.send('pong');
  }


const getCripto = async (req: any, res: any) => {
    res.send('pong');
  }
export default {getCripto}
  