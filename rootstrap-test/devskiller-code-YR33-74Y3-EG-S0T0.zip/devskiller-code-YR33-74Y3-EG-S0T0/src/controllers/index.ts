import cripto from './criptos.controller'
import ping from  './ping.controller'


export default {cripto, ping}
  